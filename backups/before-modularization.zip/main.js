const { app, BrowserWindow } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1600,
    height: 900,
    backgroundColor: '#000',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  
  win.loadFile('index.html');
  win.setMenuBarVisibility(false);
  
  // ВОТ ЭТА СТРОЧКА ОТКРОЕТ КОНСОЛЬ АВТОМАТИЧЕСКИ:
  win.webContents.openDevTools(); 
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());