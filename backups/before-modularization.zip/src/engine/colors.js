// src/engine/colors.js

export const UKRAINE_COLORS = {
  shirt:'#0057b7', shirtDark:'#003a80', shirtLight:'#2a77d7',
  shorts:'#ffd700', shortsDark:'#ccaa00',
  skin:'#f0c090', skinDark:'#d0a070',
  hair:'#3a2010', shoes:'#1a1a1a', shoesDark:'#0a0a0a', belt:'#2a2a2a',
};

export const RUSSIA_COLORS = {
  shirt:'#f5f5f5', shirtDark:'#c0c0c0', shirtLight:'#ffffff',
  shorts:'#0039a6', shortsDark:'#002a7a',
  skin:'#f0c090', skinDark:'#d0a070',
  hair:'#8a5a20', shoes:'#d52b1e', shoesDark:'#9a1e10', belt:'#d52b1e',
};

export const AMERICAN_COLORS = {
  shirt:'#d52b1e', shirtDark:'#9a1e10', shirtLight:'#ff4a3a',
  shorts:'#0039a6', shortsDark:'#002a7a',
  skin:'#f0c090', skinDark:'#d0a070',
  hair:'#ffd700', shoes:'#1a1a1a', shoesDark:'#0a0a0a', belt:'#0039a6',
};

export const CHINA_COLORS = {
  shirt:'#c91622', shirtDark:'#790b13', shirtLight:'#ed3940',
  shorts:'#b30d18', shortsDark:'#760811',
  skin:'#e8b98f', skinDark:'#bd8964', hair:'#171313',
  shoes:'#241717', shoesDark:'#100b0b', belt:'#e5b52e'
};