import { 
  ARENA_LEFT, ARENA_RIGHT, GROUND_Y, GRAVITY, MOVE_SPEED, JUMP_VELOCITY, DOUBLE_JUMP_VELOCITY, 
  DASH_SPEED, DASH_DURATION, DASH_CD, ULT_CHARGE_TIME, platforms, springs, ATTACKS, SKILLS, SKILLS_RU, SKILLS_US 
} from '../engine/config.js';
import { UKRAINE_COLORS, RUSSIA_COLORS, AMERICAN_COLORS } from '../engine/colors.js';
import { particles, crowd, spawnHitSparks, spawnKetchup, spawnDust, spawnMuzzleFlash, spawnBigExplosion, spawnExplosion, spawnLightning, doShake, flash, killRandomSpectator } from '../engine/effects.js';
import { playSound } from '../engine/audio.js';
import { projectiles, drones, bears, bombs, eagles, setHitStop } from '../engine/state.js';

function circleOverlap(a, b) {
  const dx = a.x - b.x, dy = a.y - b.y, r = a.r + b.r;
  return dx * dx + dy * dy <= r * r;
}
export class Fighter {
  constructor(x,facing,charType,name,controls){
    this.x=x; this.y=GROUND_Y; this.facing=facing;
    this.charType=charType;
    this.isUkraine=charType==='ukraine';
    this.isAmerica=charType==='america';
    this.colors = this.isUkraine ? UKRAINE_COLORS : (this.isAmerica ? AMERICAN_COLORS : RUSSIA_COLORS);
    this.name=name; this.controls=controls;
    this.hp=100; this.maxHp=100;
    this.vx=0; this.vy=0; this.onGround=true;
    this.state='idle'; this.animTime=0;
    this.attack=null; this.hitstun=0; this.hitFlash=0;
    this.blocking=false; this.specialCd=0;
    this.walkCycle=0; this.koTimer=0;
    this.skillCd={ drone:0, missile:0, bombs:0, blockade:0, bear:0, uppercut:0, flag:0, eagle:0, burger:0 };
    this.blockedTimer=0;
    this.carried=false;
    this.doubleJumpUsed=false; this.doubleJumpCd=0;
    this.dashTimer=0; this.dashCd=0; this.dashDir=0; this.dashTrail=[];
    this.ultUsed=false;
    this.ultTimer=0;
    this.ultCharging=false;
    this.ultChargeTimer=0;
    this.ultChargeDuration=this.isAmerica ? 4.0 : ULT_CHARGE_TIME;
    this._ultKeyHeld=false;
    this.shieldHp=100;
    this.shieldBroken=false;
    this.dropCooldown=0;
    this.breathing=Math.random()*Math.PI*2;
    this.bleedTimer=0;
    this.bleedTickTimer=0;
    this.healTicks=0;
    this.healTimer=0;
    this.isAI = false;
    this.aiKeys = {};
    this.aiTimer = 0;
    this.opponent = null;
  }
  reset(){
    this.maxHp = 100;
    this.hp = 100;
    this.vx=0; this.vy=0;
    this.onGround=true; this.state='idle';
    this.attack=null; this.hitstun=0; this.hitFlash=0;
    this.blocking=false; this.specialCd=0;
    this.koTimer=0; this.y=GROUND_Y;
    this.skillCd={ drone:0, missile:0, bombs:0, blockade:0, bear:0, uppercut:0, flag:0, eagle:0, burger:0 };
    this.blockedTimer=0; this.carried=false;
    this.doubleJumpUsed=false; this.doubleJumpCd=0;
    this.dashTimer=0; this.dashCd=0; this.dashTrail=[];
    this.ultUsed=false; this.ultTimer=0;
    this.ultCharging=false; this.ultChargeTimer=0; this._ultKeyHeld=false;
    this.ultChargeDuration=this.isAmerica ? 4.0 : ULT_CHARGE_TIME;
    this.shieldHp=100; this.shieldBroken=false;
    this.dropCooldown=0;
    this.animTime = 0;
    this.walkCycle = 0;
    this.breathing = 0;
    this.bleedTimer=0;
    this.bleedTickTimer=0;
    this.healTicks=0;
    this.healTimer=0;
    this.aiKeys = {};
    this.aiTimer = 0;
  }
  getSkillCd(name){
    let cd = (SKILLS[name] ? SKILLS[name].cd : (SKILLS_RU[name] ? SKILLS_RU[name].cd : (SKILLS_US[name] ? SKILLS_US[name].cd : 0)));
    return cd;
  }
  update(dt,opponent,allowInput){
    this.opponent = opponent;
    this.animTime+=dt;
    this.hitFlash=Math.max(0,this.hitFlash-dt*4);
    this.specialCd=Math.max(0,this.specialCd-dt);
    this.blockedTimer=Math.max(0,this.blockedTimer-dt);
    this.dropCooldown=Math.max(0,this.dropCooldown-dt);
    this.dashCd=Math.max(0,this.dashCd-dt);
    this.doubleJumpCd=Math.max(0,this.doubleJumpCd-dt);
    for(const k in this.skillCd) this.skillCd[k]=Math.max(0,this.skillCd[k]-dt);

    if(this.carried){ this.state='carried'; return; }

    if (!this.isDown(this.controls.ult)) {
      this._ultKeyHeld = false;
    }

    if(allowInput && this.isDown(this.controls.ult) && !this.ultUsed && !this.ultCharging && this.hp > 0 && !this._ultKeyHeld){
      this.ultChargeDuration = this.isAmerica ? 4.0 : ULT_CHARGE_TIME;
      this.ultCharging = true;
      this.ultChargeTimer = 0;
      this._ultKeyHeld = true;
      this.vx = 0;
      this.state = 'ult_charge';
      playSound(300, 0.3, 'sawtooth', 0.1);
      particles.push({x:this.x, y:this.y-200, vx:0, vy:-40, life:1.5, maxLife:1.5,
        color:'#ffcc00', size:24, isText:true, text:'ЗАРЯДКА УЛЬТЫ!'});
    }

    if(this.ultCharging) {
      this.ultChargeTimer += dt;
      this.state = 'ult_charge';
      this.vx = 0;
      if(this.isAmerica && this.ultChargeTimer >= 2 && Math.random() < 0.65){
        const a=Math.random()*Math.PI*2, r=45+Math.random()*75;
        particles.push({x:this.x+Math.cos(a)*r,y:this.y-110+Math.sin(a)*r,
          vx:Math.cos(a)*-100,vy:-120-Math.random()*100,life:0.55,maxLife:0.55,
          color:['#ffffff','#55aaff','#ff4444','#ffd700'][Math.floor(Math.random()*4)],size:4+Math.random()*5});
      }
      
      if (Math.random() < 0.7) {
          const angle = Math.random() * Math.PI * 2;
          const r = 20 + Math.random() * 60;
          particles.push({
            x: this.x + Math.cos(angle) * r,
            y: this.y - 80 + Math.sin(angle) * r,
            vx: Math.cos(angle) * -150,
            vy: Math.sin(angle) * -150 - 80,
            life: 0.5, maxLife: 0.5,
            color: ['#ff4400','#ffcc00','#ffffff','#ff8800'][Math.floor(Math.random()*4)],
            size: 3 + Math.random() * 5,
          });
        }
      
      const shakeI = 3 + (this.ultChargeTimer / this.ultChargeDuration) * 20;
      doShake(shakeI, 0.08);
      
      this.applyGravity(dt);
      return;
    }

    if(this.ultTimer>0){
      this.ultTimer -= dt;
    }

    if(this.bleedTimer > 0){
      this.bleedTimer -= dt;
      this.bleedTickTimer -= dt;
      if(this.bleedTickTimer <= 0){
        this.bleedTickTimer = 0.5;
        this.takeDamage(2, -this.facing);
        spawnKetchup(this.x, this.y-80, -this.facing, 3);
      }
    }

    if(this.healTicks > 0){
      this.healTimer -= dt;
      if(this.healTimer <= 0){
        this.healTimer = 0.7;
        this.healTicks--;
        this.hp = Math.min(this.maxHp, this.hp + 5);
        for(let i=0; i<10; i++){
          const a = Math.random()*Math.PI*2, s = 50+Math.random()*150;
          particles.push({x:this.x, y:this.y-80, vx:Math.cos(a)*s, vy:Math.sin(a)*s-50, life:0.6, maxLife:0.6, color:'#55ff55', size:4+Math.random()*4});
        }
        particles.push({x:this.x, y:this.y-100, vx:0, vy:-50, life:1.0, maxLife:1.0, color:'#55ff55', size:20, isText:true, text:'+5 HP'});
        playSound(800, 0.1, 'sine', 0.08);
      }
    }

    if(this.hp>0 && !this.attack && this.hitstun<=0){
      const wantL = this.isDown(this.controls.left);
      const wantR = this.isDown(this.controls.right);
      if(wantL && !wantR) this.facing = -1;
      else if(wantR && !wantL) this.facing = 1;
    }

    if(this.hp<=0){
      this.koTimer+=dt; this.applyGravity(dt);
      this.x+=this.vx*dt; this.vx*=0.9;
      this.clampX(); return;
    }
    if(this.hitstun>0){
      this.hitstun-=dt; this.x+=this.vx*dt; this.vx*=0.85;
      if(this.hitstun<=0) this.state='idle';
      this.clampX(); this.applyGravity(dt); return;
    }
    if(this.attack){
      this.updateAttack(dt,opponent);
      this.applyGravity(dt);
      this.x+=this.vx*dt; this.vx*=0.9;
      this.clampX(); return;
    }
    if(this.dashTimer>0){
      this.dashTimer -= dt;
      this.vx = this.dashDir * DASH_SPEED;
      this.x += this.vx * dt;
      this.clampX();
      this.applyGravity(dt);
      this.dashTrail.push({x:this.x, y:this.y, life:0.3, maxLife:0.3});
      this.state = this.onGround ? 'dash' : 'dash_air';
      return;
    }

    let moving=false;
    if(allowInput){
      const cd = this.skillCd;
      if(this.blockedTimer <= 0){
      }
      if(this.isDown(this.controls.dash) && this.dashCd<=0){
        this.startDash();
      }

      const flying = this.isAmerica && this.ultTimer > 0;
      const wantS = this.isDown(this.controls.block);
      const wantMove = this.isDown(this.controls.left) || this.isDown(this.controls.right);
      if(wantS && (this.onGround || flying) && (!wantMove || flying)){
        if(flying){ this.blocking = true; }
        else {
        const onPlat = this.getStandingPlatform();
        if(onPlat){
          this.onGround = false; this.vy = 60;
          this.dropCooldown = 0.35; this.blocking = false;
          this.doubleJumpUsed = false;
        } else {
          this.blocking = true;
        }
        }
      } else {
        this.blocking = false;
      }

      if(!this.blocking){
        if(this.isDown(this.controls.left)){ this.vx=-MOVE_SPEED*(this.facing>0?0.7:1); moving=true; }
        else if(this.isDown(this.controls.right)){ this.vx=MOVE_SPEED*(this.facing<0?0.7:1); moving=true; }
        else this.vx=0;

        if(this.isDown(this.controls.jump)){
          if(this.onGround && !this._jumpHeld){
            this.vy=JUMP_VELOCITY; this.onGround=false;
            this.doubleJumpUsed=false;
            spawnDust(this.x, this.y, 4);
            playSound(400,0.06,'sine',0.03);
            this._jumpHeld = true;
          } else if(!this.onGround && !this.doubleJumpUsed && !this._jumpHeld){
            this.vy = DOUBLE_JUMP_VELOCITY;
            this.doubleJumpUsed = true;
            this.doubleJumpCd = 3;
            for(let i=0;i<10;i++){
              const a = Math.random()*Math.PI*2, s = 80+Math.random()*150;
              particles.push({x:this.x,y:this.y-30,vx:Math.cos(a)*s,vy:Math.sin(a)*s-60,
                life:0.4,maxLife:0.4,color:'#aaddff',size:4+Math.random()*4});
            }
            playSound(600,0.08,'sine',0.05);
            this._jumpHeld = true;
          }
        } else {
          this._jumpHeld = false;
        }

        if(this.isDown(this.controls.punch)) this.startAttack('punch');
        else if(this.isDown(this.controls.kick)) this.startAttack('kick');
        else if(this.isDown(this.controls.special) && this.specialCd<=0){
          this.startAttack('chargedPunch');
          this.specialCd = ATTACKS.chargedPunch.cd;
        }
      } else if(flying){
        if(this.isDown(this.controls.left)){ this.vx=-MOVE_SPEED*(this.facing>0?0.7:1); moving=true; }
        else if(this.isDown(this.controls.right)){ this.vx=MOVE_SPEED*(this.facing<0?0.7:1); moving=true; }
        else this.vx=0;
      }
    } else { this.blocking=false; this.vx=0; }

    this.x+=this.vx*dt;
    this.clampX();
    if(this.isAmerica && this.ultTimer > 0){
      const rise=this.isDown(this.controls.jump);
      const descend=this.isDown(this.controls.block);
      const flySpeed=MOVE_SPEED*1.55;
      if(rise && !descend) this.y-=flySpeed*dt;
      else if(descend) this.y+=flySpeed*dt;
      this.y=Math.max(120,Math.min(GROUND_Y,this.y));
      this.onGround=this.y>=GROUND_Y-1;
      this.vy=0;
    } else {
      this.applyGravity(dt);
    }

    if(!this.onGround) this.state = 'jump';
    else if(this.blocking) this.state='block';
    else if(moving){ this.state='walk'; this.walkCycle+=dt*10; }
    else { this.state='idle'; this.breathing+=dt*3; }
  }
  startDash(){
    this.dashTimer = DASH_DURATION;
    this.dashCd = DASH_CD;
    this.dashDir = this.facing;
    this.vy = 0;
    this.dashTrail = [];
    playSound(500,0.1,'sine',0.06);
    playSound(700,0.08,'triangle',0.04);
  }
  getStandingPlatform(){
    for(const plat of platforms){
      if(Math.abs(this.y - plat.y) < 5 && this.x + 25 > plat.x && this.x - 25 < plat.x + plat.w){
        return plat;
      }
    }
    return null;
  }
  castBlockade(){
    projectiles.push({
      x:this.x+this.facing*50, y:this.y-90,
      vx:this.facing*900, vy:0, r:16, damage:5,
      owner:this, color:'#cc66ff', type:'blockade', trail:[],
    });
    spawnMuzzleFlash(this.x+this.facing*55,this.y-90,this.facing);
    doShake(5,0.1);
    playSound(400,0.15,'triangle',0.1);
    playSound(600,0.1,'sawtooth',0.08);
  }
  castBearSkill(){
    const startX = this.x + this.facing*40;
    bears.push({
      x: Math.max(ARENA_LEFT+80, Math.min(ARENA_RIGHT-80, startX)),
      y: this.y, facing: this.facing, vx: this.facing*650,
      owner: this, target: this.opponent,
      carrying:null, life:1.2, animTime:0,
    });
    spawnDust(this.x,this.y,15);
    doShake(10,0.2);
    playSound(60,0.4,'sawtooth',0.15);
    particles.push({x:this.x, y:this.y-180, vx:0, vy:-40, life:1.0, maxLife:1.0, color:'#ffaa44', size:28, isText:true, text:'МЕДВЕДЬ!'});
  }
  castBombs(){
    const dir = this.facing;
    for(let i=0; i<5; i++){
      bombs.push({
        x: this.x + dir*(80 + i*90 + Math.random()*60),
        y: this.y - 900 - i*90 - Math.random()*80,
        vx: dir*50, vy: 0,
        spin: Math.random()*Math.PI*2,
        target: this.opponent,
        owner: this, damage: 15, exploded: false, life: 6,
      });
    }
    doShake(6, 0.15);
    playSound(200, 0.4, 'sawtooth', 0.08);
    playSound(80, 0.3, 'square', 0.1);
    particles.push({x:this.x, y:this.y-200, vx:0, vy:-40, life:1.2, maxLife:1.2, color:'#ff8800', size:26, isText:true, text:'💣 БОМБЫ!'});
  }
  applyGravity(dt){
    if(this.isAmerica && this.ultTimer > 0){ this.vy=0; this.onGround=false; return; }
    if(this.onGround){
      if(this.y >= GROUND_Y - 2) return;
      if(!this.getStandingPlatform()) this.onGround = false;
      else return;
    }
    this.vy += GRAVITY * dt;
    const prevY = this.y;
    this.y += this.vy * dt;

    if(this.vy > 0 && this.dropCooldown <= 0){
      for(const plat of platforms){
        if(this.x + 25 > plat.x && this.x - 25 < plat.x + plat.w){
          if(prevY <= plat.y && this.y >= plat.y){
            this.y = plat.y; this.vy = 0; this.onGround = true;
            this.doubleJumpUsed = false; this.doubleJumpCd = 0;
            spawnDust(this.x, plat.y, 4);
            return;
          }
        }
      }
    }

    if(this.y >= GROUND_Y){
      let onSpring = false;
      for(const s of springs){
        if(Math.abs(this.x - s.x) < 45){
          onSpring = true;
          this.vy = -1500;
          this.onGround = false;
          this.doubleJumpUsed = false;
          spawnDust(this.x, GROUND_Y, 12);
          playSound(300, 0.15, 'sine', 0.08);
          playSound(800, 0.1, 'triangle', 0.05);
          break;
        }
      }
      if(!onSpring){
        this.y = GROUND_Y; this.vy = 0; this.onGround = true;
        this.doubleJumpUsed = false; this.doubleJumpCd = 0;
        if(Math.abs(prevY - GROUND_Y) > 30) spawnDust(this.x, GROUND_Y, 5);
      }
    }
  }
  clampX(){ this.x = Math.max(ARENA_LEFT+30, Math.min(ARENA_RIGHT-30, this.x)); }
  startAttack(type){
    const cfg = ATTACKS[type] || ATTACKS.punch;
    this.attack = {type, timer:0,
      totalTime: cfg.startup+cfg.active+cfg.recovery,
      startupEnd: cfg.startup, activeEnd: cfg.startup+cfg.active,
      hasHit:false, spawned:false};
    if(type==='punch') playSound(180,0.05,'square',0.05);
    else if(type==='kick') playSound(140,0.07,'square',0.06);
    else if(type==='uppercut') playSound(120,0.1,'sawtooth',0.12);
    else if(type==='chargedPunch'){
      playSound(150,0.3,'sawtooth',0.1);
      particles.push({x:this.x, y:this.y-200, vx:0, vy:-40, life:1.2, maxLife:1.2,
        color:'#ffaa00', size:24, isText:true, text:'ЗАРЯД...'});
    }
  }
  updateAttack(dt,opponent){
    const a=this.attack; a.timer+=dt;
    let phase;
    if(a.timer<a.startupEnd) phase='startup';
    else if(a.timer<a.activeEnd) phase='active';
    else phase='recovery';

    if(a.type==='chargedPunch' && phase==='startup'){
      if(Math.random() < 0.6){
        const angle = Math.random()*Math.PI*2;
        const r = 40 + Math.random()*60;
        particles.push({
          x: this.x + Math.cos(angle)*r + this.facing*30,
          y: this.y - 90 + Math.sin(angle)*r,
          vx: -Math.cos(angle)*180, vy: -Math.sin(angle)*180,
          life: 0.35, maxLife: 0.35,
          color: Math.random()<0.5 ? '#ffcc00' : '#ff8800', size: 3 + Math.random()*4,
        });
      }
    }

    if(phase==='active' && !a.hasHit){
      if(a.type==='punch'||a.type==='kick'||a.type==='uppercut'||a.type==='chargedPunch'){
        const cfg=ATTACKS[a.type];
        const hb={x:this.x+this.facing*cfg.range, y:this.y+cfg.hitY, r:cfg.hitR};
        if(circleOverlap(hb, opponent.getHurtbox())){
          opponent.takeDamage(cfg.damage, this.facing);
          if(cfg.knockback) opponent.vx = this.facing*cfg.knockback;
          if(cfg.launch){ opponent.vy = -900; opponent.onGround = false; }
          a.hasHit = true;
          spawnHitSparks(hb.x, hb.y, '#ffff88');
          doShake(a.type==='chargedPunch'?30 : a.type==='uppercut'?16 : a.type==='kick'?10 : 6,
            a.type==='chargedPunch'?0.35 : 0.15);
          setHitStop(a.type==='chargedPunch'?0.15 : 0.06);
          for(const c of crowd) c.excited = a.type==='chargedPunch'?3 : 1.5;
          playSound(a.type==='chargedPunch'?80 : 200, 0.15, 'square', 0.12);
          if(a.type==='chargedPunch'){
            flash('rgba(255,200,0,0.4)');
            particles.push({x:hb.x, y:hb.y, vx:0, vy:-60, life:1.0, maxLife:1.0,
              color:'#ffaa00', size:32, isText:true, text:'БУМ!'});
          }
          if(Math.random()<0.35) killRandomSpectator();
        }
      }
    }
    if(a.timer >= a.totalTime) this.attack = null;
  }
  getHurtbox(){ return {x:this.x, y:this.y-80, r:42}; }
  isDown(code){
    if (this.isAI) {
        if(Array.isArray(code)) return code.some(c=>this.aiKeys[c]===true);
        return this.aiKeys[code]===true;
    }
    if(Array.isArray(code)) return code.some(c=>window.keys[c]===true);
    return window.keys[code]===true;
  }
  takeDamage(dmg, dir){
    if(this.isAmerica && this.ultCharging && this.ultChargeTimer >= 2) return;

    if(this.isAmerica && this.ultTimer > 0 && this.blocking && this.shieldHp > 0){
      const absorbed=Math.min(dmg,this.shieldHp);
      this.shieldHp-=absorbed;
      dmg-=absorbed;
      spawnHitSparks(this.x-this.facing*35,this.y-100,'#55bbff');
      playSound(520,0.07,'triangle',0.09);
      if(this.shieldHp<=0 && !this.shieldBroken){
        this.shieldHp=0; this.shieldBroken=true;
        particles.push({x:this.x,y:this.y-150,vx:0,vy:-45,life:1.2,maxLife:1.2,color:'#ffcc44',size:24,isText:true,text:'ЩИТ СЛОМАН!'});
        doShake(10,0.18);
      }
      if(dmg<=0) return;
    }

    if (this.ultCharging) {
      this.ultCharging = false;
      this.ultChargeTimer = 0;
      if (this.state === 'ult_charge') this.state = 'idle';
      particles.push({x:this.x, y:this.y-200, vx:0, vy:-40, life:1.0, maxLife:1.0,
        color:'#ff4444', size:24, isText:true, text:'ПРЕРВАНО!'});
      playSound(200, 0.2, 'sawtooth', 0.1);
    }
    
    if(this.ultTimer > 0 && !this.isUkraine){
      dmg *= 0.5;
    }
    if(this.blocking && this.onGround && !(this.isAmerica && this.ultTimer > 0)){
      this.hp -= dmg*0.15;
      this.hitFlash = Math.max(this.hitFlash, 0.3);
      spawnHitSparks(this.x-dir*20, this.y-80, '#88aaff');
      playSound(400,0.05,'triangle',0.06); return;
    }
    this.hp -= dmg;
    this.hitFlash = 0.5;
    this.hitstun = Math.min(0.4, dmg*0.04);
    this.vx = dir*(150+dmg*15);
    this.state = 'hit';
    spawnHitSparks(this.x, this.y-80, '#ff8888');
    spawnKetchup(this.x, this.y-80, dir, Math.min(18, 4 + Math.floor(dmg)));
    playSound(250,0.08,'sawtooth',0.08);
    if(this.attack && this.attack.type==='chargedPunch'){
      this.attack = null;
      particles.push({x:this.x, y:this.y-140, vx:0, vy:-40, life:0.8, maxLife:0.8,
        color:'#ff4444', size:20, isText:true, text:'ПРЕРВАНО'});
    }
    if(this.hp<=0){
      this.hp=0; this.state='ko'; this.vx=dir*200;
      doShake(25,0.3); playSound(100,0.6,'sawtooth',0.15);
      for(let k=0;k<3;k++) killRandomSpectator();
    }
  }
}