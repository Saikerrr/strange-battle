import { UKRAINE_COLORS, RUSSIA_COLORS, AMERICAN_COLORS, CHINA_COLORS } from '../engine/colors.js';

export const ROSTER = [
  { 
    id: 'ukraine', 
    name: 'УКРАИНА', 
    colors: UKRAINE_COLORS, 
    flag: 'UA', 
    teaser: 'Дрон · Ракета · Бомбы', 
    desc: '+20% max HP · Иммунитет' 
  },
  { 
    id: 'russia', 
    name: 'РОССИЯ', 
    colors: RUSSIA_COLORS, 
    flag: 'RU', 
    teaser: 'Блокада · Медведь · Апперкот', 
    desc: '-50% урона · откидывает' 
  },
  { 
    id: 'america', 
    name: 'АМЕРИКА', 
    colors: AMERICAN_COLORS, 
    flag: 'US', 
    teaser: 'Флаг · Орёл · Бургер', 
    desc: 'Щит · Полёт' 
  },
  { 
    id: 'china', 
    name: 'КИТАЙ', 
    colors: CHINA_COLORS, 
    flag: 'CN', 
    teaser: 'Доширак · Фейерверк · Фонарь', 
    desc: 'Дракон · Крылья' 
  }
];