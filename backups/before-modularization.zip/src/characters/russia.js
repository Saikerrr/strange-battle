import { Fighter } from '../entities/Fighter.js';
import { projectiles, bears } from '../engine/state.js';
import { particles, spawnHitSparks, spawnDust, spawnBigExplosion, doShake } from '../engine/effects.js';
import { playSound } from '../engine/audio.js';
import { ARENA_LEFT, ARENA_RIGHT } from '../engine/config.js';

export function initRussia(deps) {
  const { game, ctx, p1, p2, crowd, drawFighter: originalDrawFighter, getPlayerSkills: originalGetPlayerSkills } = deps;

  // Ульта России (Киборг)
  function russiaTriggerUlt(f, opp) {
    if (f.ultUsed) return;
    f.ultUsed = true;
    f.state = 'idle'; f.hitstun = 0; f.attack = null;
    f.ultTimer = 10;
    
    spawnBigExplosion(f.x, f.y - 60);
    if(opp && !opp.dead){
      const dir = opp.x > f.x ? 1 : -1;
      opp.takeDamage(15, dir);
      opp.vx = dir * 2400;
      opp.vy = -1500;
      opp.onGround = false;
      opp.hitstun = 1.5;
    }
    doShake(38, 0.6);
    playSound(50,0.7,'sawtooth',0.3);
    playSound(1400,0.3,'square',0.15);
    playSound(80,0.5,'square',0.2);
    particles.push({x:f.x, y:f.y-260, vx:0, vy:-60, life:2.0, maxLife:2.0, color:'#ff4422', size:56, isText:true, text:'КИБОРГ!'});
    particles.push({x:f.x, y:f.y-210, vx:0, vy:-40, life:2.0, maxLife:2.0, color:'#ffaa00', size:22, isText:true, text:'-50% УРОНА'});
    for(const c of crowd) c.excited = 3;
  }

  // Перехватываем базовый апдейт
  const _oldUpdate = Fighter.prototype.update;
  Fighter.prototype.update = function (dt, opponent, allowInput) {
    // Перехват ульты для России
    if (this.charType === 'russia' && this.ultCharging && this.ultChargeTimer + dt >= this.ultChargeDuration) {
      this.ultCharging = false;
      russiaTriggerUlt(this, opponent);
      this.applyGravity(dt);
      return;
    }

    _oldUpdate.call(this, dt, opponent, allowInput);

    if (this.charType !== 'russia' || this.trainingDummy) return;
    if (!allowInput || this.hitstun > 0 || this.carried || this.hp <= 0 || this.ultCharging) return;

    const cd = this.skillCd;
    if (this.blockedTimer <= 0) {
      if (this.isDown(this.controls.skill1) && cd.blockade <= 0) { this.castBlockade(); cd.blockade = 8; }
      if (this.isDown(this.controls.skill2) && cd.bear <= 0) { this.castBearSkill(); cd.bear = 12; }
      if (this.isDown(this.controls.skill3) && cd.uppercut <= 0) { this.startAttack('uppercut'); cd.uppercut = 6; }
    }
  };

  // Иконки скиллов России в HUD
  const russiaGetPlayerSkills = function (f) {
    if (f.charType === 'russia') {
      return [
        { key: f === p1 ? 'Z' : 'N1', icon: '🚫', cd: f.skillCd.blockade },
        { key: f === p1 ? 'X' : 'N2', icon: '🐻', cd: f.skillCd.bear },
        { key: f === p1 ? 'C' : 'N3', icon: '👊', cd: f.skillCd.uppercut },
      ];
    }
    return originalGetPlayerSkills(f);
  };

  // Отрисовка ауры Киборга
  const russiaDrawFighter = function (f) {
    originalDrawFighter(f);
    if (f.charType !== 'russia' || f.ultTimer <= 0) return;
    
    const t = f.animTime || 0;
    ctx.save();
    ctx.globalAlpha = 0.35 + Math.sin(t*12)*0.2;
    const ag = ctx.createRadialGradient(f.x, f.y-100, 10, f.x, f.y-100, 150);
    ag.addColorStop(0,'rgba(255,60,20,0.5)');
    ag.addColorStop(1,'rgba(255,20,0,0)');
    ctx.fillStyle = ag;
    ctx.beginPath(); ctx.arc(f.x, f.y-100, 150, 0, Math.PI*2); ctx.fill();
    
    ctx.strokeStyle = `rgba(255,100,50,${0.6+Math.sin(t*15)*0.3})`;
    ctx.lineWidth = 2;
    for(let i=0; i<6; i++){
      const ang = i*Math.PI/3 + t*2;
      const x1 = f.x + Math.cos(ang)*100;
      const y1 = f.y - 100 + Math.sin(ang)*100;
      const x2 = f.x + Math.cos(ang)*140;
      const y2 = f.y - 100 + Math.sin(ang)*140;
      ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y2); ctx.stroke();
    }
    ctx.restore();
  };

  return {
    getPlayerSkills: russiaGetPlayerSkills,
    drawFighter: russiaDrawFighter
  };
}