import { Fighter } from '../entities/Fighter.js';
import { projectiles, drones, bombs, tombstones, miniZombies } from '../engine/state.js';
import { particles, spawnHitSparks, spawnLightning, doShake, flash, killRandomSpectator, spawnDust, spawnExplosion } from '../engine/effects.js';
import { playSound } from '../engine/audio.js';
import { ARENA_LEFT, ARENA_RIGHT, GROUND_Y, ATTACKS } from '../engine/config.js';

export function initUkraine(deps) {
  const { game, ctx, p1, p2, crowd, zombieWaves, drawFighter: originalDrawFighter, getPlayerSkills: originalGetPlayerSkills, drawWorld: originalDrawWorld, updateGame: originalUpdateGame } = deps;

  function launchDrone(owner) {
    drones.push({x:owner.x,y:owner.y-160,owner,target:owner.opponent,fireTimer:0.3,life:3.5,rotor:0});
  }

  function launchMissile(owner) {
    const target = owner.opponent;
    projectiles.push({x:owner.x,y:owner.y-350,vx:0,vy:0,r:12,damage:20,owner,color:'#ff5544',type:'missile',target,homing:true,trail:[]});
  }

  // --- МОГИЛЫ И ЗОМБИ ---
  function sbCastTomb(owner) {
    const x = Math.max(ARENA_LEFT+80, Math.min(ARENA_RIGHT-80, owner.x + owner.facing*170));
    tombstones.push({x, y:GROUND_Y, hp:5, owner, timer:3, life:10, dead:false});
    particles.push({x, y:GROUND_Y-180, vx:0, vy:-42, life:1, maxLife:1, color:'#9bff73', size:20, isText:true, text:'МОГИЛА ЗОМБИ'});
    doShake(5, 0.12);
  }

  function updateTombs(dt) {
    for(let i=tombstones.length-1; i>=0; i--){
      const t=tombstones[i]; t.life-=dt; t.timer-=dt;
      if(t.timer<=0 && t.life>0){
        t.timer=3;
        miniZombies.push({x:t.x, y:GROUND_Y, vx:0, owner:t.owner, target:t.owner===p1?p2:p1, state:'run', timer:0, life:7, hit:false});
      }
      if(t.life<=0 || t.hp<=0){ tombstones.splice(i,1); spawnDust(t.x, GROUND_Y, 10); }
    }
    for(const t of tombstones){
      for(const attacker of [p1,p2]){
        if(attacker===t.owner) continue;
        const a=attacker.attack;
        if(a && !a.hasHit && (a.type==='punch'||a.type==='kick')){
          const cfg=ATTACKS[a.type];
          if(a.timer>=a.startupEnd && a.timer<a.activeEnd && Math.abs(attacker.x-t.x)<cfg.range+40 && Math.abs(attacker.y-t.y)<90){
            t.hp--; a.hasHit=true; spawnHitSparks(t.x,t.y-50,'#aaff77');
          }
        }
      }
    }
    for(const z of miniZombies){
      const enemy=z.owner===p1?p2:p1;
      const a=enemy.attack;
      if(a && !a.hasHit && (a.type==='punch'||a.type==='kick')){
        const cfg=ATTACKS[a.type];
        if(a.timer>=a.startupEnd && a.timer<a.activeEnd && Math.abs(enemy.x-z.x)<cfg.range+28 && Math.abs(enemy.y-z.y)<75){
          z.life=0; a.hasHit=true; spawnHitSparks(z.x,z.y-25,'#aaff77');
        }
      }
    }
    for(let i=miniZombies.length-1; i>=0; i--){
      const z=miniZombies[i]; z.life-=dt; z.timer+=dt;
      if(z.state==='run' && z.target && z.target.hp>0){
        const dx=z.target.x-z.x; z.vx=Math.sign(dx)*185; z.x+=z.vx*dt;
        if(Math.abs(dx)<62 && Math.abs(z.target.y-z.y)<90){ z.state='windup'; z.timer=0; }
      } else if(z.state==='windup' && z.timer>=.5){
        z.state='jump'; z.timer=0; z.jumpAge=0; z.jumpStartX=z.x; z.jumpDuration=.42;
      } else if(z.state==='jump'){
        z.jumpAge+=dt; const pr=Math.min(1,z.jumpAge/z.jumpDuration);
        if(z.target && z.target.hp>0) z.x = z.jumpStartX + (z.target.x - z.jumpStartX)*pr;
        z.y = GROUND_Y - Math.sin(pr*Math.PI)*95;
        if(pr>=1){
          if(z.target && z.target.hp>0){ z.x=z.target.x; z.target.takeDamage(5, z.owner.x<z.target.x?1:-1); }
          z.state='explode'; z.timer=0; z.y=GROUND_Y;
        }
      } else if(z.state==='explode' && !z.hit){
        spawnExplosion(z.x, GROUND_Y-35); z.hit=true; z.life=0;
      }
      if(z.life<=0) miniZombies.splice(i,1);
    }
  }

  function drawTombs() {
    for(const t of tombstones){
      ctx.save(); ctx.translate(t.x,t.y);
      ctx.fillStyle='rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(0,0,48,10,0,0,Math.PI*2); ctx.fill();
      ctx.fillStyle='#555'; ctx.beginPath(); ctx.roundRect(-24,-85,48,78,8); ctx.fill();
      ctx.strokeStyle='#aaa'; ctx.lineWidth=4; ctx.stroke();
      ctx.fillStyle='#888'; ctx.fillRect(-5,-72,10,48); ctx.fillRect(-16,-55,32,8);
      ctx.fillStyle='#9dff73'; ctx.font='bold 13px Arial'; ctx.textAlign='center'; ctx.fillText(''+t.hp+'/5',0,-98);
      ctx.restore();
    }
    for(const z of miniZombies){
      ctx.save(); ctx.translate(z.x,z.y);
      ctx.fillStyle='#72a84b'; ctx.beginPath(); ctx.arc(0,-28,13,0,Math.PI*2); ctx.fill();
      ctx.fillStyle='#28351b'; ctx.fillRect(-10,-18,20,22);
      ctx.strokeStyle='#b7e878'; ctx.lineWidth=4; ctx.beginPath(); ctx.moveTo(-7,-5); ctx.lineTo(-18,2); ctx.moveTo(7,-5); ctx.lineTo(18,2); ctx.stroke();
      ctx.fillStyle='#fff'; ctx.fillRect(-5,-31,4,4); ctx.fillRect(3,-31,4,4);
      if(z.state==='windup'){ ctx.strokeStyle='#d9ff99'; ctx.lineWidth=3; ctx.beginPath(); ctx.arc(0,-35,23,Math.PI,Math.PI*2); ctx.stroke(); }
      ctx.restore();
    }
  }

  // --- ЛОГИКА УКРАИНЫ ---
  const _oldUpdate = Fighter.prototype.update;
  Fighter.prototype.update = function (dt, opponent, allowInput) {
    _oldUpdate.call(this, dt, opponent, allowInput);
    if (!this.isUkraine || this.trainingDummy) return;

    if (this.ultTimer > 0) {
      this.zombieWaveTimer -= dt;
      if (this.zombieWaveTimer <= 0) {
        this.zombieWaveTimer = 0.6;
        if (opponent && !opponent.dead) {
          const dist = Math.hypot(opponent.x - this.x, opponent.y - this.y);
          if (dist < 320) opponent.takeDamage(4, opponent.x > this.x ? 1 : -1);
        }
        zombieWaves.push({x:this.x, y:this.y-40, r:30, maxR:320, life:0.5, maxLife:0.5});
        playSound(150, 0.12, 'sawtooth', 0.08);
        doShake(6, 0.1);
      }
    }
    if (!allowInput || this.hitstun > 0 || this.carried || this.hp <= 0 || this.ultCharging) return;
    
    const cd = this.skillCd;
    if (this.blockedTimer <= 0) {
      if (this.isDown(this.controls.skill1) && cd.drone <= 0) { launchDrone(this); cd.drone = 8; playSound(800,0.15,'triangle',0.08); }
      if (this.isDown(this.controls.skill2) && cd.missile <= 0) { launchMissile(this); cd.missile = 10; playSound(300,0.3,'sawtooth',0.1); }
      if (this.isDown(this.controls.skill3) && cd.bombs <= 0) {
        if (this.ultTimer > 0) sbCastTomb(this);
        else this.castBombs();
        cd.bombs = 10;
      }
    }
  };

  function uaTriggerUlt(f, opp) {
    if (f.ultUsed) return;
    f.ultUsed = true; f.state = 'idle'; f.hitstun = 0; f.attack = null;
    f.ultTimer = 10; f.maxHp = Math.floor(f.maxHp * 1.2); f.hp = Math.min(f.maxHp, f.hp + 20); f.zombieWaveTimer = 0.3;
    spawnLightning(f.x, f.y); doShake(60, 1.0);
    particles.push({x:f.x, y:f.y-260, vx:0, vy:-60, life:2.0, maxLife:2.0, color:'#88ff44', size:56, isText:true, text:'ЗОМБИ!'});
    particles.push({x:f.x, y:f.y-210, vx:0, vy:-40, life:2.0, maxLife:2.0, color:'#ffd700', size:22, isText:true, text:'+20% MAX HP'});
    for(const c of crowd) c.excited = 3;
    for(let k=0;k<3;k++) killRandomSpectator();
  }

  const _oldUpdateGame = originalUpdateGame;
  deps.updateGame = function(dt) {
    _oldUpdateGame(dt);
    if (game.state === 'fighting') {
      updateTombs(dt);
      // Проверка ульты Украины
      for (const f of [p1, p2]) {
        if (f.isUkraine && f.ultCharging && f.ultChargeTimer >= f.ultChargeDuration) {
          f.ultCharging = false;
          uaTriggerUlt(f, f === p1 ? p2 : p1);
        }
      }
    }
  };

  const uaGetPlayerSkills = function (f) {
    if (f.isUkraine) {
      return [
        { key: f === p1 ? 'Z' : 'N1', icon: '🛸', cd: f.skillCd.drone },
        { key: f === p1 ? 'X' : 'N2', icon: '🚀', cd: f.skillCd.missile },
        { key: f === p1 ? 'C' : 'N3', icon: '💣', cd: f.skillCd.bombs },
      ];
    }
    return originalGetPlayerSkills(f);
  };

  const uaDrawFighter = function (f) {
    originalDrawFighter(f);
    if (!f.isUkraine || f.ultTimer <= 0) return;
    const t = f.animTime || 0;
    ctx.save(); ctx.globalAlpha = 0.3 + Math.sin(t*12)*0.15;
    const ag = ctx.createRadialGradient(f.x, f.y-100, 10, f.x, f.y-100, 150);
    ag.addColorStop(0,'rgba(120,255,80,0.4)'); ag.addColorStop(1,'rgba(80,180,40,0)');
    ctx.fillStyle = ag; ctx.beginPath(); ctx.arc(f.x, f.y-100, 150, 0, Math.PI*2); ctx.fill();
    ctx.strokeStyle = `rgba(180,255,100,${0.6+Math.sin(t*20)*0.3})`; ctx.lineWidth = 2;
    for(let i=0; i<4; i++){
      const ang = i*Math.PI/2 + t*3;
      const x1 = f.x + Math.cos(ang)*90, y1 = f.y - 100 + Math.sin(ang)*90;
      const x2 = f.x + Math.cos(ang)*130, y2 = f.y - 100 + Math.sin(ang)*130;
      ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y2); ctx.stroke();
    }
    ctx.restore();
  };

  const _oldDrawWorld = originalDrawWorld;
  deps.drawWorld = function(t) {
    _oldDrawWorld(t);
    drawTombs();
  };

  return {
    getPlayerSkills: uaGetPlayerSkills,
    drawFighter: uaDrawFighter,
    drawWorld: deps.drawWorld,
    updateGame: deps.updateGame
  };
}