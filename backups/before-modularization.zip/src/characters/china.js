import { Fighter } from '../entities/Fighter.js';
import { CHINA_COLORS } from '../engine/colors.js';
import { particles, spawnHitSparks, spawnMuzzleFlash, doShake } from '../engine/effects.js';
import { playSound } from '../engine/audio.js';

export function initChina(deps) {
  const { ctx, W, H, p1, p2, game, buttons, sbName, drawCharCard, drawMiniPortrait, drawControlsPanel, drawSelectPanel, drawFlagUA, drawFlagRU, drawFlagUS } = deps;

  function drawFlagChina(x,y,w,h){
    ctx.fillStyle='#de2910'; ctx.fillRect(x,y,w,h);
    ctx.fillStyle='#ffde00';
    ctx.beginPath();ctx.arc(x+w*.22,y+h*.28,Math.max(2,h*.12),0,Math.PI*2);ctx.fill();
    for(const [sx,sy] of [[.43,.15],[.52,.29],[.52,.48],[.43,.62]]){
      ctx.beginPath();ctx.arc(x+w*sx,y+h*sy,Math.max(1.2,h*.035),0,Math.PI*2);ctx.fill();
    }
    ctx.strokeStyle='#000';ctx.lineWidth=1;ctx.strokeRect(x,y,w,h);
  }
  deps.drawFlagChina = drawFlagChina;

  const cnNoodle   = [];
  const cnFireworks = [];
  const cnLanterns = [];
  const cnFireCones = [];
  const cnTails    = [];
  const cnRoars    = [];

  function cnText(x, y, txt, color = '#fff') {
    particles.push({ x, y, vx: 0, vy: -42, life: 1.2, maxLife: 1.2, color, size: 20, isText: true, text: txt });
  }

  function cnInit(f) {
    if (f._cnInit) return;
    f._cnInit = true;
    f.noodleCharges = 0;
    f.noodleMode = false;
    f.fireworkCd = 0;
    f.lanternCd = 0;
    f.breathCd = 0;
    f.tailCd = 0;
    f.roarCd = 0;
    f._cnZHeld = false;
    f._cnXHeld = false;
    f._cnCHeld = false;
    f.burnTimer = 0;
    f.burnInterval = 0;
    f.burnDmg = 0;
    f.burnTicksLeft = 0;
    f.slowTimer = 0;
    if (!f.skillCd.noodle) f.skillCd.noodle = 0;
  }

  // Перезаписываем reset, чтобы у Китая сбрасывались кулдауны
  const cnResetPrev = Fighter.prototype.reset;
  Fighter.prototype.reset = function () {
    cnResetPrev.call(this);
    this._cnInit = false;
    cnInit(this);
    this.skillCd.noodle = 0;
  };

  // Перезаписываем update для логики Китая
  const cnUpdatePrev = Fighter.prototype.update;
  Fighter.prototype.update = function (dt, opponent, allowInput) {
    cnUpdatePrev.call(this, dt, opponent, allowInput);
    if (!this.isChina || this.trainingDummy) return;
    cnInit(this);

    this.fireworkCd = Math.max(0, this.fireworkCd - dt);
    this.lanternCd  = Math.max(0, this.lanternCd  - dt);
    this.breathCd   = Math.max(0, this.breathCd   - dt);
    this.tailCd     = Math.max(0, this.tailCd     - dt);
    this.roarCd     = Math.max(0, this.roarCd     - dt);

    if (this.burnTimer > 0) {
      this.burnTimer -= dt;
      this.burnInterval -= dt;
      if (this.burnInterval <= 0) {
        this.burnInterval = 1;
        this.takeDamage(this.burnDmg, -this.facing);
        spawnHitSparks(this.x, this.y - 80, '#ff6600');
        this.burnTicksLeft--;
        if (this.burnTicksLeft <= 0) this.burnTimer = 0;
      }
    }

    if (this.slowTimer > 0) {
      this.slowTimer -= dt;
      this.x -= this.vx * 0.5 * dt;
      this.clampX();
    }

    if (!allowInput || this.hitstun > 0 || this.carried || this.hp <= 0 || this.ultCharging) return;

    const zDown = this.isDown(this.controls.skill1);
    const xDown = this.isDown(this.controls.skill2);
    const cDown = this.isDown(this.controls.skill3);

    if (this.ultTimer > 0) {
      if (zDown && !this._cnZHeld && this.breathCd <= 0) {
        this.cnBreath(opponent); this.breathCd = 3; this._cnZHeld = true;
      }
      if (!zDown) this._cnZHeld = false;

      if (xDown && !this._cnXHeld && this.tailCd <= 0) {
        this.cnTail(opponent); this.tailCd = 4; this._cnXHeld = true;
      }
      if (!xDown) this._cnXHeld = false;

      if (cDown && !this._cnCHeld && this.roarCd <= 0) {
        this.cnRoar(opponent); this.roarCd = 5; this._cnCHeld = true;
      }
      if (!cDown) this._cnCHeld = false;
    } else {
      if (zDown && !this._cnZHeld) {
        this._cnZHeld = true;
        if (this.noodleCharges === 0 && this.skillCd.noodle <= 0) {
          this.noodleCharges = 5;
          this.noodleMode = true;
          cnText(this.x, this.y - 200, '🍜 ДОШИРАК x5', '#ff8844');
          playSound(600, 0.15, 'sine', 0.08);
        } else if (this.noodleCharges > 0) {
          this.cnNoodleShot(opponent);
          this.noodleCharges--;
          if (this.noodleCharges === 0) {
            this.noodleMode = false;
            this.skillCd.noodle = 15;
            particles.push({ x: this.x + this.facing * 30, y: this.y - 90, vx: this.facing * 250, vy: -300, life: 0.8, maxLife: 0.8, color: '#ff6600', size: 12, gravity: 1200 });
            cnText(this.x, this.y - 160, 'ПУСТО!', '#ffaa44');
          }
        }
      }
      if (!zDown) this._cnZHeld = false;

      if (xDown && !this._cnXHeld && this.fireworkCd <= 0) {
        this.cnFirework(opponent); this.fireworkCd = 5; this._cnXHeld = true;
      }
      if (!xDown) this._cnXHeld = false;

      if (cDown && !this._cnCHeld && this.lanternCd <= 0) {
        this.cnLantern(opponent); this.lanternCd = 10; this._cnCHeld = true;
      }
      if (!cDown) this._cnCHeld = false;
    }
  };

  Fighter.prototype.cnNoodleShot = function (target) {
    const dir = this.facing;
    cnNoodle.push({ x: this.x + dir * 42, y: this.y - 90, vx: dir * 1400, vy: 0, r: 10, damage: 5, life: 1.5, owner: this, target, trail: [] });
    spawnMuzzleFlash(this.x + dir * 45, this.y - 90, dir);
    playSound(900, 0.06, 'square', 0.06);
  };

  Fighter.prototype.cnFirework = function (target) {
    const dir = this.facing;
    cnFireworks.push({ x0: this.x + dir * 50, y0: this.y - 120, x: this.x + dir * 50, y: this.y - 120, tx: this.x + dir * 280, ty: this.y - 40, age: 0, duration: 0.6, owner: this, target, radius: 130, damage: 10 });
    cnText(this.x, this.y - 170, '🎆 ФЕЙЕРВЕРК', '#ffcc00');
    playSound(500, 0.15, 'sine', 0.1);
    playSound(800, 0.2, 'triangle', 0.08);
  };

  Fighter.prototype.cnLantern = function (target) {
    cnLanterns.push({ x: this.x + this.facing * 30, y: this.y - 100, owner: this, life: 4, age: 0, fireCd: 0.3, radius: 300 });
    cnText(this.x, this.y - 180, '🏮 ФОНАРЬ', '#ffcc00');
    playSound(700, 0.2, 'triangle', 0.1);
  };

  Fighter.prototype.cnBreath = function (target) {
    cnFireCones.push({ x: this.x, y: this.y - 80, dir: this.facing, length: 450, width: 200, life: 0.6, maxLife: 0.6, owner: this, hit: new Set() });
    playSound(200, 0.3, 'sawtooth', 0.15);
    doShake(8, 0.2);
  };

  Fighter.prototype.cnTail = function (target) {
    cnTails.push({ x: this.x, y: this.y - 80, radius: 200, life: 0.4, maxLife: 0.4, owner: this });
    playSound(120, 0.2, 'sawtooth', 0.15);
    doShake(15, 0.25);
    if (target && target.hp > 0 && Math.hypot(target.x - this.x, 0) < 200) {
      target.takeDamage(12, this.facing);
      target.hitstun = 0.4;
      target.starStunTimer = 0.4;
      target.vx = this.facing * 400;
      if (!target.onGround) target.vy = 200;
    }
  };

  Fighter.prototype.cnRoar = function (target) {
    cnRoars.push({ x: this.x, y: this.y - 80, radius: 250, life: 0.6, maxLife: 0.6, owner: this });
    playSound(80, 0.5, 'sawtooth', 0.2);
    doShake(20, 0.3);
    if (target && target.hp > 0 && Math.hypot(target.x - this.x, 0) < 250) {
      target.takeDamage(8, this.facing);
      target.slowTimer = 2;
    }
  };

  // --- УЛЬТА КИТАЯ (ВОЗВРАЩАЕМ ДРАКОНА) ---
  // Мы не можем перезаписать импортированный triggerUlt, поэтому добавляем свой обработчик в update
  const cnUltCheck = Fighter.prototype.update;
  Fighter.prototype.update = function(dt, opponent, allowInput) {
    // Если игра попыталась вызвать ульту, а мы Китай - перехватываем
    if (this.isChina && this.ultCharging && this.ultChargeTimer >= this.ultChargeDuration) {
      this.ultCharging = false;
      this.ultUsed = true;
      this.ultTimer = 10;
      this.ultCooldown = 30;
      this.state = 'idle'; this.hitstun = 0; this.attack = null;
      this.maxHp = Math.floor(this.maxHp * 1.2);
      this.hp = Math.min(this.maxHp, this.hp + 20);

      for (let i = 0; i < 80; i++) {
        const a = Math.random() * Math.PI * 2, s = 100 + Math.random() * 400;
        particles.push({ x: this.x, y: this.y - 100, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 150, life: 1.2 + Math.random() * 0.8, maxLife: 2.0, color: ['#ffcc00', '#ffaa00', '#ff8800', '#ffffff'][Math.floor(Math.random() * 4)], size: 5 + Math.random() * 8 });
      }
      for (let i = 0; i < 4; i++) {
        deps.explosionRings.push({ x: this.x, y: this.y - 100, r: 20 + i * 10, maxR: 400 + i * 100, life: 0.6 + i * 0.1, maxLife: 0.7, color: `rgba(255,${200 - i * 30},0,` });
      }
      doShake(40, 0.8);
      playSound(300, 0.5, 'sawtooth', 0.2);
      playSound(800, 0.3, 'triangle', 0.15);
      particles.push({ x: this.x, y: this.y - 260, vx: 0, vy: -60, life: 2.0, maxLife: 2.0, color: '#ffcc00', size: 56, isText: true, text: '🐉 ДРАКОН!' });
      cnText(this.x, this.y - 210, '+20% MAX HP', '#ffd700');
      for (const c of deps.crowd) c.excited = 3;
      return;
    }
    cnUltCheck.call(this, dt, opponent, allowInput);
  };

  function cnUpdateProjectiles(dt) {
    for (let i = cnNoodle.length - 1; i >= 0; i--) {
      const n = cnNoodle[i];
      n.life -= dt; n.x += n.vx * dt; n.y += n.vy * dt;
      n.trail.push({ x: n.x, y: n.y });
      if (n.trail.length > 10) n.trail.shift();
      const t = n.target;
      if (t && t.hp > 0 && !t.carried && Math.hypot(n.x - t.x, n.y - (t.y - 80)) < 50) {
        t.takeDamage(n.damage, n.owner.facing);
        spawnHitSparks(n.x, n.y, '#ffcc00');
        cnNoodle.splice(i, 1);
        continue;
      }
      if (n.life <= 0 || n.x < deps.ARENA_LEFT || n.x > deps.ARENA_RIGHT) cnNoodle.splice(i, 1);
    }

    for (let i = cnFireworks.length - 1; i >= 0; i--) {
      const f = cnFireworks[i];
      f.age += dt;
      const p = Math.min(1, f.age / f.duration);
      f.x = f.x0 + (f.tx - f.x0) * p;
      f.y = f.y0 + (f.ty - f.y0) * p - Math.sin(p * Math.PI) * 220;
      if (p >= 1) {
        const colors = ['#ff0044', '#ffcc00', '#00ccff', '#cc00ff', '#00ff88', '#ff6600'];
        for (let b = 0; b < 3; b++) {
          setTimeout(() => {
            for (let j = 0; j < 20; j++) {
              const a = Math.random() * Math.PI * 2, s = 150 + Math.random() * 300;
              particles.push({ x: f.tx, y: f.ty, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 100, life: 1.0 + Math.random() * 0.5, maxLife: 1.5, color: colors[Math.floor(Math.random() * colors.length)], size: 4 + Math.random() * 6, gravity: 400 });
            }
          }, b * 150);
        }
        const t = f.target;
        if (t && t.hp > 0 && Math.hypot(t.x - f.tx, t.y - 80 - f.ty) < f.radius) {
          t.takeDamage(f.damage, f.owner.facing);
        }
        doShake(8, 0.2);
        playSound(1200, 0.1, 'triangle', 0.1);
        cnFireworks.splice(i, 1);
      }
    }

    for (let i = cnLanterns.length - 1; i >= 0; i--) {
      const l = cnLanterns[i];
      l.life -= dt; l.age += dt; l.fireCd -= dt;
      if (l.life <= 0) { cnLanterns.splice(i, 1); continue; }
      if (l.fireCd <= 0) {
        l.fireCd = 0.6;
        const enemy = (l.owner === p1) ? p2 : p1;
        if (enemy && enemy.hp > 0 && Math.hypot(enemy.x - l.x, (enemy.y - 80) - (l.y - 100)) < l.radius) {
          const dx = enemy.x - l.x, dy = (enemy.y - 80) - (l.y - 100);
          const d = Math.max(0.1, Math.hypot(dx, dy));
          cnNoodle.push({ x: l.x, y: l.y - 100, vx: dx / d * 800, vy: dy / d * 800, r: 6, damage: 3, life: 1.5, owner: l.owner, target: enemy, trail: [] });
          playSound(1400, 0.04, 'square', 0.05);
        }
      }
    }

    for (let i = cnFireCones.length - 1; i >= 0; i--) {
      const c = cnFireCones[i];
      c.life -= dt;
      if (c.life <= 0) { cnFireCones.splice(i, 1); continue; }
      const t = (c.owner === p1) ? p2 : p1;
      if (t && t.hp > 0 && !c.hit.has(t)) {
        const along = (t.x - c.owner.x) * c.dir;
        const perp = Math.abs((t.y - 80) - (c.owner.y - 80));
        if (along > 0 && along < c.length && perp < c.width / 2) {
          c.hit.add(t);
          t.takeDamage(15, c.dir);
          t.burnTimer = 3; t.burnInterval = 1; t.burnDmg = 3; t.burnTicksLeft = 3;
          spawnHitSparks(t.x, t.y - 80, '#ff4400');
        }
      }
    }
    for (let i = cnTails.length - 1; i >= 0; i--) { cnTails[i].life -= dt; if (cnTails[i].life <= 0) cnTails.splice(i, 1); }
    for (let i = cnRoars.length - 1; i >= 0; i--) { cnRoars[i].life -= dt; if (cnRoars[i].life <= 0) cnRoars.splice(i, 1); }
  }

  function cnDrawProjectiles() {
    for (const n of cnNoodle) {
      for (let i = 0; i < n.trail.length; i++) {
        ctx.globalAlpha = (i / n.trail.length) * 0.5;
        ctx.fillStyle = '#ffcc00';
        ctx.beginPath(); ctx.arc(n.trail[i].x, n.trail[i].y, 4, 0, Math.PI * 2); ctx.fill();
      }
      ctx.globalAlpha = 1;
      ctx.save(); ctx.translate(n.x, n.y); ctx.rotate(Math.atan2(n.vy, n.vx));
      ctx.strokeStyle = '#ffcc00'; ctx.lineWidth = 5; ctx.lineCap = 'round';
      ctx.beginPath();
      for (let i = -15; i <= 15; i += 3) {
        const yy = Math.sin(i * 0.5 + performance.now() * 0.02) * 3;
        if (i === -15) ctx.moveTo(i, yy); else ctx.lineTo(i, yy);
      }
      ctx.stroke(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke();
      ctx.restore();
    }

    for (const f of cnFireworks) {
      ctx.save(); ctx.translate(f.x, f.y);
      ctx.globalAlpha = 0.4; ctx.fillStyle = '#ff6600';
      for (let i = 1; i <= 3; i++) { ctx.beginPath(); ctx.arc(-i * 8, i * 10, 6 - i, 0, Math.PI * 2); ctx.fill(); }
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#ffcc00'; ctx.beginPath(); ctx.arc(0, 0, 7, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(0, 0, 3, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
    }

    for (const l of cnLanterns) {
      const bob = Math.sin(l.age * 3) * 5;
      ctx.save(); ctx.translate(l.x, l.y - 100 + bob);
      const glow = ctx.createRadialGradient(0, 0, 20, 0, 0, l.radius);
      glow.addColorStop(0, 'rgba(255,180,0,0.25)'); glow.addColorStop(0.5, 'rgba(255,120,0,0.1)'); glow.addColorStop(1, 'rgba(255,80,0,0)');
      ctx.fillStyle = glow; ctx.beginPath(); ctx.arc(0, 0, l.radius, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#cc1100'; ctx.beginPath(); ctx.ellipse(0, 0, 22, 30, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#ffcc00'; ctx.lineWidth = 2; ctx.stroke();
      ctx.strokeStyle = '#ff8800'; ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(0, 0, 15, 22, 0, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = '#ffcc00'; ctx.fillRect(-8, -32, 16, 4); ctx.fillRect(-8, 28, 16, 4);
      ctx.strokeStyle = '#ffcc00'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(0, 32); ctx.lineTo(0, 45); ctx.stroke();
      ctx.restore();
    }

    for (const c of cnFireCones) {
      const a = c.life / c.maxLife;
      ctx.save(); ctx.globalAlpha = a;
      ctx.translate(c.owner.x, c.owner.y - 80); ctx.scale(c.dir, 1);
      const grad = ctx.createRadialGradient(0, 0, 0, 0, 0, c.length);
      grad.addColorStop(0, 'rgba(255,255,100,0.9)'); grad.addColorStop(0.4, 'rgba(255,150,0,0.6)'); grad.addColorStop(1, 'rgba(255,50,0,0)');
      ctx.fillStyle = grad;
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(c.length, -c.width / 2); ctx.lineTo(c.length, c.width / 2); ctx.closePath(); ctx.fill();
      for (let i = 0; i < 12; i++) {
        const px = Math.random() * c.length, py = (Math.random() - 0.5) * c.width * (px / c.length);
        ctx.fillStyle = `rgba(255,${180 + Math.random() * 75},0,${a})`;
        ctx.beginPath(); ctx.arc(px, py, 3 + Math.random() * 4, 0, Math.PI * 2); ctx.fill();
      }
      ctx.restore();
    }

    for (const t of cnTails) {
      const a = t.life / t.maxLife;
      ctx.save(); ctx.globalAlpha = a;
      ctx.strokeStyle = '#ffcc00'; ctx.lineWidth = 8;
      ctx.beginPath(); ctx.arc(t.x, t.y, t.radius * (1 - a * 0.5), 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(t.x, t.y, t.radius * (1 - a * 0.5), 0, Math.PI * 2); ctx.stroke();
      ctx.restore();
    }

    for (const r of cnRoars) {
      const a = r.life / r.maxLife;
      ctx.save(); ctx.globalAlpha = a;
      for (let ring = 0; ring < 3; ring++) {
        const rr = r.radius * (1 - a * 0.5) + ring * 40;
        ctx.strokeStyle = `rgba(255,215,0,${a})`; ctx.lineWidth = 4 - ring;
        ctx.beginPath(); ctx.arc(r.x, r.y, rr, 0, Math.PI * 2); ctx.stroke();
      }
      ctx.restore();
    }
  }

    const cnDrawFighterPrev = deps.drawFighter;
  const myDrawFighter = function (f) {
    cnDrawFighterPrev(f);
    if (!f.isChina) return;

    if (f.noodleMode && f.noodleCharges > 0 && f.ultTimer <= 0 && !f.trainingDummy) {
      ctx.save(); ctx.translate(f.x + f.facing * 42, f.y - 85); ctx.scale(f.facing, 1);
      ctx.fillStyle = '#ff6600'; ctx.beginPath(); ctx.roundRect(-12, -15, 24, 30, 3); ctx.fill();
      ctx.strokeStyle = '#cc3300'; ctx.lineWidth = 2; ctx.stroke();
      ctx.fillStyle = '#ffaa44'; ctx.fillRect(-12, -15, 24, 6);
      ctx.fillStyle = '#fff'; ctx.font = 'bold 14px Arial'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText('D', 0, 4);
      ctx.fillStyle = '#ffcc00'; ctx.font = 'bold 12px Arial'; ctx.fillText('x' + f.noodleCharges, 22, -12);
      ctx.restore();
    }

    if (f.ultTimer > 0) {
      const t = performance.now();
      ctx.save(); ctx.translate(f.x, f.y); ctx.scale(f.facing, 1);
      const tail = Math.sin(t * 0.008) * 8;
      ctx.strokeStyle = '#ffcc00'; ctx.lineWidth = 12; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(0, -60); ctx.quadraticCurveTo(-70, -30 + tail, -110, -80 + tail); ctx.stroke();
      ctx.strokeStyle = '#aa8800'; ctx.lineWidth = 3; ctx.stroke();
      ctx.fillStyle = '#ff6600'; ctx.beginPath(); ctx.arc(-110, -80 + tail, 10, 0, Math.PI * 2); ctx.fill();
      const wp = Math.sin(t * 0.01);
      ctx.save(); ctx.translate(-20, -110); ctx.rotate(-0.7 + wp * 0.3);
      ctx.fillStyle = 'rgba(255,180,0,0.6)';
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(-60, -40, -90, 0); ctx.quadraticCurveTo(-70, 25, -40, 20); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = '#aa6600'; ctx.lineWidth = 2; ctx.stroke();
      ctx.restore();
      ctx.save(); ctx.translate(-20, -110); ctx.rotate(-0.5 + wp * 0.3);
      ctx.fillStyle = 'rgba(255,215,0,0.7)';
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(-50, -30, -80, -10); ctx.quadraticCurveTo(-70, 20, -50, 30); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = '#aa6600'; ctx.lineWidth = 2; ctx.stroke();
      for (let i = 1; i <= 3; i++) { ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(-60 + i * 15, -20 + i * 12); ctx.stroke(); }
      ctx.restore();
      ctx.strokeStyle = 'rgba(255,215,0,0.5)'; ctx.lineWidth = 1;
      for (let y = -140; y < -80; y += 15) { for (let x = -15; x < 15; x += 10) { ctx.beginPath(); ctx.arc(x, y, 4, 0, Math.PI); ctx.stroke(); } }
      ctx.restore();
      ctx.save(); ctx.globalAlpha = 0.3 + Math.sin(t * 0.01) * 0.15;
      const ag = ctx.createRadialGradient(f.x, f.y - 100, 20, f.x, f.y - 100, 180);
      ag.addColorStop(0, 'rgba(255,215,0,0.5)'); ag.addColorStop(1, 'rgba(255,180,0,0)');
      ctx.fillStyle = ag; ctx.beginPath(); ctx.arc(f.x, f.y - 100, 180, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
    }
  };

  const cnDrawWorldPrev = deps.drawWorld;
  const myDrawWorld = function (t) {
    cnDrawWorldPrev(t);
    cnDrawProjectiles();
  };

  const cnUpdateGamePrev = deps.updateGame;
  const myUpdateGame = function (dt) {
    cnUpdateGamePrev(dt);
    if (deps.game.state === 'fighting') cnUpdateProjectiles(dt);
  };

  const cnSkillsPrev = deps.getPlayerSkills;
  const myGetPlayerSkills = function (f) {
    if (f.isChina) {
      if (f.ultTimer > 0) {
        return [
          { key: f === p1 ? 'Z' : 'N1', icon: '🔥', cd: f.breathCd || 0 },
          { key: f === p1 ? 'X' : 'N2', icon: '🌀', cd: f.tailCd || 0 },
          { key: f === p1 ? 'C' : 'N3', icon: '📢', cd: f.roarCd || 0 }
        ];
      }
      const zCd = f.noodleMode ? 0 : (f.skillCd.noodle || 0);
      const zIcon = f.noodleMode ? ('🍜' + f.noodleCharges) : '🍜';
      return [
        { key: f === p1 ? 'Z' : 'N1', icon: zIcon, cd: zCd },
        { key: f === p1 ? 'X' : 'N2', icon: '🎆', cd: f.fireworkCd || 0 },
        { key: f === p1 ? 'C' : 'N3', icon: '🏮', cd: f.lanternCd || 0 }
      ];
    }
    return cnSkillsPrev(f);
  };

  return {
    drawFighter: myDrawFighter,
    drawWorld: myDrawWorld,
    updateGame: myUpdateGame,
    getPlayerSkills: myGetPlayerSkills
  };
}

