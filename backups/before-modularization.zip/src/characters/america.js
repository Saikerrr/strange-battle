import { Fighter } from '../entities/Fighter.js';
import { projectiles, eagles, shieldBoomerangs } from '../engine/state.js';
import { particles, spawnHitSparks, spawnDust, spawnMuzzleFlash, doShake, flash } from '../engine/effects.js';
import { playSound } from '../engine/audio.js';

export function initAmerica(deps) {
  const { game, ctx, p1, p2, crowd, drawFighter: originalDrawFighter, getPlayerSkills: originalGetPlayerSkills, drawWorld: originalDrawWorld, updateGame: originalUpdateGame } = deps;

  function castFlag(f) {
    const p = { x:f.x+f.facing*50, y:f.y-90, vx:f.facing*1200, vy:0, r:24, damage:12, owner:f, color:'#d52b1e', type:'flag', trail:[] };
    if (f.ultTimer > 0) { p.isUltFlag = true; p.r = 34; }
    projectiles.push(p);
    spawnMuzzleFlash(f.x+f.facing*55, f.y-90, f.facing);
    doShake(6, 0.1);
    playSound(400, 0.15, 'triangle', 0.1);
  }

  function castEagle(f) {
    const target = f.opponent;
    const count = f.ultTimer > 0 ? 2 : 1;
    for (let i = 0; i < count; i++) {
      const fromLeft = count === 1 ? (f.facing > 0) : (i === 0);
      eagles.push({ x: fromLeft ? -50 : 1650, y: -130 - i*55, target, owner: f, state: 'swoop', timer: 0, scale: f.ultTimer > 0 ? 1.65 : 1.25, laneOffset: count === 2 ? (i === 0 ? -24 : 24) : 0, facing: target.x >= f.x ? 1 : -1 });
    }
    playSound(800, 0.2, 'triangle', 0.1); playSound(1200, 0.1, 'sine', 0.1);
  }

  function castBurger(f) {
    if (f.ultTimer > 0) {
      shieldBoomerangs.push({ x: f.x + f.facing*45, y: f.y-90, vx: f.facing*760, vy: -80, owner: f, target: f.opponent, age: 0, life: 2.6, hit: false });
      playSound(500, 0.16, 'triangle', 0.1);
      particles.push({x:f.x, y:f.y-170, vx:0, vy:-42, life:1.0, maxLife:1.0, color:'#65baff', size:20, isText:true, text:'ЩИТ-БУМЕРАНГ!'});
    } else {
      f.healTicks = 3; f.healTimer = 0.7;
      particles.push({ x:f.x, y:f.y-200, vx:0, vy:-40, life:1.0, maxLife:1.0, color:'#55ff55', size:26, isText:true, text:'🍔 БУРГЕР!' });
      playSound(600, 0.2, 'sine', 0.08);
    }
  }

  // --- ЩИТ-БУМЕРАНГ ---
  function updateBoomerangs(dt) {
    for(let i=shieldBoomerangs.length-1; i>=0; i--){
      const b=shieldBoomerangs[i]; b.age+=dt; b.life-=dt;
      const target=b.target; const returning=b.age>.55;
      if(!returning && target && target.hp>0){ const dy=(target.y-85)-b.y; b.vy+=(Math.max(-220,Math.min(220,dy*1.8))-b.vy)*dt*3; }
      else { const dx=b.owner.x-b.x, dy=(b.owner.y-85)-b.y, d=Math.hypot(dx,dy)||1; b.vx+=(dx/d*850-b.vx)*dt*4; b.vy+=(dy/d*850-b.vy)*dt*4; }
      b.x+=b.vx*dt; b.y+=b.vy*dt;
      if(!b.hit && target && target.hp>0 && circleOverlap({x:b.x,y:b.y,r:24}, target.getHurtbox())){
        target.takeDamage(12, b.owner.facing); b.hit=true; spawnHitSparks(b.x,b.y,'#65baff');
      }
      if(b.life<=0 || Math.hypot(b.owner.x-b.x, b.owner.y-85-b.y)<38) shieldBoomerangs.splice(i,1);
    }
  }

  function drawBoomerangs() {
    for(const b of shieldBoomerangs){
      ctx.save(); ctx.translate(b.x,b.y); ctx.rotate(b.age*15);
      ctx.shadowColor='#55aaff'; ctx.shadowBlur=18;
      ctx.fillStyle='#b9d9f5'; ctx.beginPath(); ctx.arc(0,0,23,0,Math.PI*2); ctx.fill();
      ctx.fillStyle='#1b4e9b'; ctx.beginPath(); ctx.arc(0,0,12,0,Math.PI*2); ctx.fill();
      ctx.strokeStyle='#fff'; ctx.lineWidth=4; ctx.beginPath(); ctx.arc(0,0,18,0,Math.PI*2); ctx.stroke();
      ctx.restore();
    }
  }

  function circleOverlap(a, b) {
    const dx = a.x - b.x, dy = a.y - b.y, r = a.r + b.r;
    return dx * dx + dy * dy <= r * r;
  }

  // --- ЛОГИКА АМЕРИКИ ---
  const _oldUpdate = Fighter.prototype.update;
  Fighter.prototype.update = function (dt, opponent, allowInput) {
    _oldUpdate.call(this, dt, opponent, allowInput);
    if (this.charType !== 'america' || this.trainingDummy) return;
    if (!allowInput || this.hitstun > 0 || this.carried || this.hp <= 0 || this.ultCharging) return;

    const cd = this.skillCd;
    if (this.blockedTimer <= 0) {
      if (this.isDown(this.controls.skill1) && cd.flag <= 0) { castFlag(this); cd.flag = 10; }
      if (this.isDown(this.controls.skill2) && cd.eagle <= 0) { castEagle(this); cd.eagle = 7; }
      if (this.isDown(this.controls.skill3) && cd.burger <= 0) { castBurger(this); cd.burger = 15; }
    }
  };

  function americaTriggerUlt(f, opp) {
    if (f.ultUsed) return;
    f.ultUsed = true; f.state = 'idle'; f.hitstun = 0; f.attack = null;
    f.ultTimer = 10; f.shieldHp = 100; f.shieldBroken = false; f.vx = 0; f.vy = 0;
    spawnDust(f.x, f.y, 18);
    for(let i=0; i<34; i++){
      const a=Math.random()*Math.PI*2, sp=100+Math.random()*360;
      particles.push({x:f.x, y:f.y-110, vx:Math.cos(a)*sp, vy:Math.sin(a)*sp-120, life:0.8+Math.random()*0.4, maxLife:1.2, color:['#ffffff','#55aaff','#ff4444','#ffd700'][Math.floor(Math.random()*4)], size:4+Math.random()*7});
    }
    particles.push({x:f.x, y:f.y-250, vx:0, vy:-50, life:1.8, maxLife:1.8, color:'#ffd700', size:44, isText:true, text:'КАПИТАН АМЕРИКА!'});
    flash('rgba(255,255,255,0.8)'); doShake(28, 0.45);
    playSound(880, 0.25, 'triangle', 0.13); playSound(440, 0.4, 'sine', 0.1);
    for(const c of crowd) c.excited = 3;
  }

  const _oldUpdateGame = originalUpdateGame;
  deps.updateGame = function(dt) {
    _oldUpdateGame(dt);
    if (game.state === 'fighting') {
      updateBoomerangs(dt);
      // Проверка ульты Америки
      for (const f of [p1, p2]) {
        if (f.charType === 'america' && f.ultCharging && f.ultChargeTimer >= f.ultChargeDuration) {
          f.ultCharging = false;
          americaTriggerUlt(f, f === p1 ? p2 : p1);
        }
      }
    }
  };

  const americaGetPlayerSkills = function (f) {
    if (f.charType === 'america') {
      return [
        { key: f === p1 ? 'Z' : 'N1', icon: '🇺🇸', cd: f.skillCd.flag },
        { key: f === p1 ? 'X' : 'N2', icon: '🦅', cd: f.skillCd.eagle },
        { key: f === p1 ? 'C' : 'N3', icon: f.ultTimer > 0 ? '🛡' : '🍔', cd: f.skillCd.burger },
      ];
    }
    return originalGetPlayerSkills(f);
  };

  const americaDrawFighter = function (f) {
    originalDrawFighter(f);
    if (f.charType !== 'america' || f.ultTimer <= 0) return;
    const t = f.animTime || 0;
    ctx.save(); ctx.globalAlpha = 0.18 + Math.sin(t*8)*0.06;
    const ag = ctx.createRadialGradient(f.x, f.y-100, 15, f.x, f.y-100, 125);
    ag.addColorStop(0,'rgba(100,180,255,0.65)'); ag.addColorStop(1,'rgba(255,255,255,0)');
    ctx.fillStyle = ag; ctx.beginPath(); ctx.arc(f.x, f.y-100, 125, 0, Math.PI*2); ctx.fill();
    ctx.restore();
  };

  const _oldDrawWorld = originalDrawWorld;
  deps.drawWorld = function(t) {
    _oldDrawWorld(t);
    drawBoomerangs();
  };

  return {
    getPlayerSkills: americaGetPlayerSkills,
    drawFighter: americaDrawFighter,
    drawWorld: deps.drawWorld,
    updateGame: deps.updateGame
  };
}